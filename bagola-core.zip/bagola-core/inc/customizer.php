<?php
/*======
*
* Kirki Settings
*
======*/
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Kirki' ) ) {
	return;
}

Kirki::add_config(
	'Bagola_customizer', array(
		'capability'  => 'edit_theme_options',
		'option_type' => 'theme_mod',
	)
);

/*======
*
* Sections
*
======*/
$sections = array(
	'shop_settings' => array (
		esc_attr__( 'Shop Settings', 'Bagola-core' ),
		esc_attr__( 'You can customize the shop settings.', 'Bagola-core' ),
	),
	
	'blog_settings' => array (
		esc_attr__( 'Blog Settings', 'Bagola-core' ),
		esc_attr__( 'You can customize the blog settings.', 'Bagola-core' ),
	),

	'header_settings' => array (
		esc_attr__( 'Header Settings', 'Bagola-core' ),
		esc_attr__( 'You can customize the header settings.', 'Bagola-core' ),
	),

	'main_color' => array (
		esc_attr__( 'Main Color', 'Bagola-core' ),
		esc_attr__( 'You can customize the main color.', 'Bagola-core' ),
	),

	'elementor_templates' => array (
		esc_attr__( 'Elementor Templates', 'Bagola-core' ),
		esc_attr__( 'You can customize the elementor templates.', 'Bagola-core' ),
	),
	
	'map_settings' => array (
		esc_attr__( 'Map Settings', 'Bagola-core' ),
		esc_attr__( 'You can customize the map settings.', 'Bagola-core' ),
	),

	'footer_settings' => array (
		esc_attr__( 'Footer Settings', 'Bagola-core' ),
		esc_attr__( 'You can customize the footer settings.', 'Bagola-core' ),
	),
	
	'Bagola_widgets' => array (
		esc_attr__( 'Bagola Widgets', 'Bagola-core' ),
		esc_attr__( 'You can customize the Bagola widgets.', 'Bagola-core' ),
	),

	'gdpr_settings' => array (
		esc_attr__( 'GDPR Settings', 'Bagola-core' ),
		esc_attr__( 'You can customize the GDPR settings.', 'Bagola-core' ),
	),

	'newsletter_settings' => array (
		esc_attr__( 'Newsletter Settings', 'Bagola-core' ),
		esc_attr__( 'You can customize the Newsletter Popup settings.', 'Bagola-core' ),
	),

	'maintenance_settings' => array (
		esc_attr__( 'Maintenance Settings', 'Bagola-core' ),
		esc_attr__( 'You can customize the Maintenance settings.', 'Bagola-core' ),
	),

);

foreach ( $sections as $section_id => $section ) {
	$section_args = array(
		'title' => $section[0],
		'description' => $section[1],
	);

	if ( isset( $section[2] ) ) {
		$section_args['type'] = $section[2];
	}

	if( $section_id == "colors" ) {
		Kirki::add_section( str_replace( '-', '_', $section_id ), $section_args );
	} else {
		Kirki::add_section( 'Bagola_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
	}
}


/*======
*
* Fields
*
======*/
function Bagola_customizer_add_field ( $args ) {
	Kirki::add_field(
		'Bagola_customizer',
		$args
	);
}

	/*====== Header ==================================================================================*/
		/*====== Header Panels ======*/
		Kirki::add_panel (
			'Bagola_header_panel',
			array(
				'title' => esc_html__( 'Header Settings', 'Bagola-core' ),
				'description' => esc_html__( 'You can customize the header from this panel.', 'Bagola-core' ),
			)
		);

		$sections = array (
			'header_logo' => array(
				esc_attr__( 'Logo', 'Bagola-core' ),
				esc_attr__( 'You can customize the logo which is on header..', 'Bagola-core' )
			),
		
			'header_general' => array(
				esc_attr__( 'Header General', 'Bagola-core' ),
				esc_attr__( 'You can customize the header.', 'Bagola-core' )
			),

			'header_preloader' => array(
				esc_attr__( 'Preloader', 'Bagola-core' ),
				esc_attr__( 'You can customize the loader.', 'Bagola-core' )
			),
			
			'header_color' => array(
				esc_attr__( 'Header Style', 'Bagola-core' ),
				esc_attr__( 'You can customize the color.', 'Bagola-core' )
			),
			
			'header_location_style' => array(
				esc_attr__( 'Location Style', 'Bagola-core' ),
				esc_attr__( 'You can customize the style.', 'Bagola-core' )
			),
			
			'header_search_style' => array(
				esc_attr__( 'Search Style', 'Bagola-core' ),
				esc_attr__( 'You can customize the style.', 'Bagola-core' )
			),
			
			'header_button_style' => array(
				esc_attr__( 'Button Style', 'Bagola-core' ),
				esc_attr__( 'You can customize the style.', 'Bagola-core' )
			),
			
			'header_sidebar_menu_style' => array(
				esc_attr__( 'Sidebar Menu Style', 'Bagola-core' ),
				esc_attr__( 'You can customize the style.', 'Bagola-core' )
			),
			
			'header_mobile_sidebar_menu_style' => array(
				esc_attr__( 'Mobile Sidebar Menu Style', 'Bagola-core' ),
				esc_attr__( 'You can customize the style.', 'Bagola-core' )
			),
			
		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'Bagola_header_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'Bagola_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}
		
		/*====== Logo ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'Bagola_logo',
				'label' => esc_attr__( 'Logo', 'Bagola-core' ),
				'description' => esc_attr__( 'You can upload a logo.', 'Bagola-core' ),
				'section' => 'Bagola_header_logo_section',
				'choices' => array(
					'save_as' => 'id',
				),
			)
		);
		
		/*====== Logo ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'Bagola_mobile_logo',
				'label' => esc_attr__( 'Mobile Logo', 'Bagola-core' ),
				'description' => esc_attr__( 'You can upload a logo for the mobile.', 'Bagola-core' ),
				'section' => 'Bagola_header_logo_section',
				'choices' => array(
					'save_as' => 'id',
				),
			)
		);
		
		/*====== Logo Description ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_logo_desc',
				'label' => esc_attr__( 'Set Logo Description', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set logo description.', 'Bagola-core' ),
				'section' => 'Bagola_header_logo_section',
				'default' => 'Online Grocery Shopping Center',
			)
		);
		
		/*====== Logo Text ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_logo_text',
				'label' => esc_attr__( 'Set Logo Text', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set logo as text.', 'Bagola-core' ),
				'section' => 'Bagola_header_logo_section',
				'default' => 'Bagola',
			)
		);

		/*====== Logo Size ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'Bagola_logo_size',
				'label'       => esc_html__( 'Logo Size', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set size of the logo.', 'Bagola-core' ),
				'section'     => 'Bagola_header_logo_section',
				'default'     => 164,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 20,
					'max'  => 400,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.site-header .header-main .site-brand img.desktop-logo',
					'property'    => 'width',
					'units' => 'px',
				], ],
			)
		);
		
		/*====== Mobil Logo Size ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'Bagola_mobil_logo_size',
				'label'       => esc_html__( 'Mobile Logo Size', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set size of the mobil logo.', 'Bagola-core' ),
				'section'     => 'Bagola_header_logo_section',
				'default'     => 93,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 20,
					'max'  => 300,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.site-header .header-main .site-brand img.mobile-logo',
					'property'    => 'width',
					'units' => 'px',
				], ],
			)
		);
		
		/*====== Sidebar Logo Size ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'Bagola_sidebar_logo_size',
				'label'       => esc_html__( 'Sidebar Logo Size', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set size of the sidebar logo.', 'Bagola-core' ),
				'section'     => 'Bagola_header_logo_section',
				'default'     => 127,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 20,
					'max'  => 300,
					'step' => 1,
				],
				'output' => [
				[
					'element' => '.site-canvas .canvas-header .site-brand img',
					'property'    => 'width',
					'units' => 'px',
				], ],
			)
		);
		
		Bagola_customizer_add_field(
			array (
			'type'        => 'select',
			'settings'    => 'Bagola_header_type',
			'label'       => esc_html__( 'Header Type', 'Bagola-core' ),
			'section'     => 'Bagola_header_general_section',
			'default'     => 'type-1',
			'priority'    => 10,
			'choices'     => array(
				'type1' => esc_attr__( 'Type 1', 'Bagola-core' ),
				'type2' => esc_attr__( 'Type 2', 'Bagola-core' ),
			),
			) 
		);

		/*====== Middle Sticky Header Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_middle_sticky_header',
				'label' => esc_attr__( 'Middle Sticky Header', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the header on the mobile.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
			)
		);

		/*====== Mobile Sticky Header Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_mobile_sticky_header',
				'label' => esc_attr__( 'Mobile Sticky Header', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the header on the mobile.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Location Filter Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_location_filter',
				'label' => esc_attr__( 'Location Filter', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the location filter on the header.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
			)
		);

		/*====== Location Filter Popup Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_location_filter_popup',
				'label' => esc_attr__( 'Popup Location Filter', 'Bagola-core' ),
				'description' => esc_attr__( 'Enable popup location.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'Bagola_location_filter',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Search Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_header_search',
				'label' => esc_attr__( 'Header Search', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the search on the header.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Ajax Search Form ======*/
		if ( class_exists( 'DGWT_WC_Ajax_Search' )){
			Bagola_customizer_add_field (
				array(
					'type' => 'toggle',
					'settings' => 'Bagola_ajax_search_form',
					'label' => esc_attr__( 'Ajax Search Form Search Holder', 'Bagola-core' ),
					'description' => esc_attr__( 'Replace the search bar which is on the search holder.', 'Bagola-core' ),
					'section' => 'Bagola_header_general_section',
					'default' => '0',
					'required' => array(
						array(
						  'setting'  => 'Bagola_header_search',
						  'operator' => '==',
						  'value'    => '1',
						),
					),
				)
			);
		}
		
		/*====== Header Cart Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_header_cart',
				'label' => esc_attr__( 'Header Cart', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the mini cart on the header.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
			)
		);

		/*====== Header Mini Cart Type ======*/
		Bagola_customizer_add_field(
			array (
			'type'        => 'radio-buttonset',
			'settings'    => 'Bagola_header_mini_cart_type',
			'label'       => esc_html__( 'Mini Cart Type', 'Bagola-core' ),
			'section'     => 'Bagola_header_general_section',
			'default'     => 'default',
			'priority'    => 10,
			'choices'     => array(
				'sidecart' => esc_attr__( 'Side Cart', 'Bagola-core' ),
				'default' => esc_attr__( 'Default', 'Bagola-core' ),
			),
			'required' => array(
				array(
				  'setting'  => 'Bagola_header_cart',
				  'operator' => '==',
				  'value'    => '1',
				),
			),
			) 
		);
		
		/*====== Header Mini Cart Notice ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_header_mini_cart_notice',
				'label' => esc_attr__( 'Mini Cart Notice', 'Bagola-core' ),
				'description' => esc_attr__( 'You can add a text for the mini cart.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_header_cart',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Header Account Icon ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_header_account',
				'label' => esc_attr__( 'Account Icon / Login', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable User Login/Signup on the header.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Header Sidebar ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_header_sidebar',
				'label' => esc_attr__( 'Sidebar Menu', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable Sidebar Menu', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
			)
		);

		/*====== Header Sidebar Collapse ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_header_sidebar_collapse',
				'label' => esc_attr__( 'Disable Collapse on Frontpage', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable Sidebar Collapse on Home Page.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'Bagola_header_sidebar',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Top Header Notice Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_top_header_notice',
				'label' => esc_attr__( 'Top Header Notice', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable the top header notice.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Top Header Notice Text ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'Bagola_top_header_notice_text',
				'label' => esc_attr__( 'Header Top Notice Text', 'Bagola-core' ),
				'description' => esc_attr__( 'You can add a text for the top header notice.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => 'Due to the <strong>COVID 19</strong> epidemic, orders may be processed with a slight delay',
				'required' => array(
					array(
					  'setting'  => 'Bagola_top_header_notice',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Top Header Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_top_header',
				'label' => esc_attr__( 'Top Header', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable the top header.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '0',
			)
		);
		
		/*====== Top Header Bar Text ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_top_header_text_icon',
				'label' => esc_attr__( 'Top Header Text Icon', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set an icon. for example: secure', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => 'secure',
				'required' => array(
					array(
					  'setting'  => 'Bagola_top_header',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Top Header Bar Text ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'Bagola_top_header_text',
				'label' => esc_attr__( 'Top Header Text', 'Bagola-core' ),
				'description' => esc_attr__( 'You can add a text for the top bar text.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => '100% Secure delivery without contacting the courier',
				'required' => array(
					array(
					  'setting'  => 'Bagola_top_header',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Top Header Content Text ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'Bagola_top_header_content_text',
				'label' => esc_attr__( 'Top Header Content Text', 'Bagola-core' ),
				'description' => esc_attr__( 'You can add a content text for the top bar.', 'Bagola-core' ),
				'section' => 'Bagola_header_general_section',
				'default' => 'Need help? Call Us: <strong style="color: #2bbef9;">+ 0020 500</strong>',
				'required' => array(
					array(
					  'setting'  => 'Bagola_top_header',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== PreLoader Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_preloader',
				'label' => esc_attr__( 'Enable Loader', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable the loader.', 'Bagola-core' ),
				'section' => 'Bagola_header_preloader_section',
				'default' => '0',
			)
		);
		
		/*====== Top Header Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_top_bg_color',
				'label' => esc_attr__( 'Top Header Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_header_color_section',
			)
		);

		/*====== Top Header Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#3e445a',
				'settings' => 'Bagola_top_color',
				'label' => esc_attr__( 'Top Header Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_header_color_section',
			)
		);
		
		/*====== Top Header Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#2bbef9',
				'settings' => 'Bagola_top_hvrcolor',
				'label' => esc_attr__( 'Top Header Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for hover color.', 'Bagola-core' ),
				'section' => 'Bagola_header_color_section',
			)
		);

		/*====== Header Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_bg_color',
				'label' => esc_attr__( 'Header Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_header_color_section',
			)
		);
		
		/*====== Header Font Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#3e445a',
				'settings' => 'Bagola_color',
				'label' => esc_attr__( 'Header Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'Bagola-core' ),
				'section' => 'Bagola_header_color_section',
			)
		);

		/*====== Header Font BG Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#f0faff',
				'settings' => 'Bagola_header_font_background_hover_color',
				'label' => esc_attr__( 'Header Font Background Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font background.', 'Bagola-core' ),
				'section' => 'Bagola_header_color_section',
			)
		);

		/*====== Header Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#2bbef9',
				'settings' => 'Bagola_hvr_color',
				'label' => esc_attr__( 'Header Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for hover color.', 'Bagola-core' ),
				'section' => 'Bagola_header_color_section',
			)
		);
		
		/*====== Top Header Typography ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'Bagola_top_header_size',
				'label'       => esc_attr__( 'Top Header Typography', 'Bagola-core' ),
				'section'     => 'Bagola_header_color_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '12px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-header .header-top ',
					],
				],
			)
		);
		
		/*====== Header Typography ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'Bagola_header_size',
				'label'       => esc_attr__( 'Header Typography', 'Bagola-core' ),
				'section'     => 'Bagola_header_color_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '15px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-header .all-categories + .primary-menu .menu > .menu-item > a, nav.site-menu.primary-menu.horizontal .menu > .menu-item > a, .site-header .primary-menu .menu .sub-menu .menu-item > a',
					],
				],		
			)
		);
		
		/*======  Location Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_lct_bg_color',
				'label' => esc_attr__( 'Location Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_header_location_style_section',
			)
		);
		
		/*======  Location Background Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_lct_bg_hvrcolor',
				'label' => esc_attr__( 'Location Background Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for hover background.', 'Bagola-core' ),
				'section' => 'Bagola_header_location_style_section',
			)
		);
		
		/*======  Location Border Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#d9d9e9',
				'settings' => 'Bagola_lct_brdr_color',
				'label' => esc_attr__( 'Location Border Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  Border.', 'Bagola-core' ),
				'section' => 'Bagola_header_location_style_section',
			)
		);
		
		/*======  Location Border Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#d9d9e9',
				'settings' => 'Bagola_lct_brdr_hvrcolor',
				'label' => esc_attr__( 'Location Border Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for hover  Border.', 'Bagola-core' ),
				'section' => 'Bagola_header_location_style_section',
			)
		);
		
		/*======  Location Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#3e445a',
				'settings' => 'Bagola_lct_color',
				'label' => esc_attr__( ' Location Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_header_location_style_section',
			)
		);
		
		/*======  Location Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#3e445a',
				'settings' => 'Bagola_lct_hvrcolor',
				'label' => esc_attr__( ' Location Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for hover color.', 'Bagola-core' ),
				'section' => 'Bagola_header_location_style_section',
			)
		);
		
		/*======  Location Second Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#233a95',
				'settings' => 'Bagola_lct_scnd_color',
				'label' => esc_attr__( ' Location Second Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_header_location_style_section',
			)
		);
		
		/*======  Location Second Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#233a95',
				'settings' => 'Bagola_lct_scnd_hvrcolor',
				'label' => esc_attr__( ' Location Second Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for hover color.', 'Bagola-core' ),
				'section' => 'Bagola_header_location_style_section',
			)
		);
		
		/*======  Location Arrow Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#233a95',
				'settings' => 'Bagola_lct_arrow_color',
				'label' => esc_attr__( ' Location Arrow Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_header_location_style_section',
			)
		);
		
		/*====== Location Typography ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'Bagola_header_lct_size',
				'label'       => esc_attr__( 'Location Typography', 'Bagola-core' ),
				'section'     => 'Bagola_header_location_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-location a .location-description , .site-location a .current-location ',
					],
				],
			)
		);
		
		/*======  Search Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#f3f4f7',
				'settings' => 'Bagola_search_bg_color',
				'label' => esc_attr__( 'Search Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_header_search_style_section',
			)
		);
		
		/*======  Search Border Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#f3f4f7',
				'settings' => 'Bagola_search_brdrcolor',
				'label' => esc_attr__( 'Search Border Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_search_style_section',
			)
		);
		
		/*======  Search Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_search_color',
				'label' => esc_attr__( 'Search Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_search_style_section',
			)
		);
		
		/*======  Search Icon Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_search_icon_color',
				'label' => esc_attr__( 'Search Icon Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_search_style_section',
			)
		);
		
		/*======  Login Button Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_login_btn_bg_color',
				'label' => esc_attr__( 'Login Button Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_header_button_style_section',
			)
		);
		
		/*======  Login Button Border Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#e2e4ec',
				'settings' => 'Bagola_login_btn_brdrcolor',
				'label' => esc_attr__( 'Login Button Border Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  border color.', 'Bagola-core' ),
				'section' => 'Bagola_header_button_style_section',
			)
		);
		
		/*======  Login Button Icon Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#3e445a',
				'settings' => 'Bagola_login_btn_color',
				'label' => esc_attr__( 'Login Button Icon Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for icon color.', 'Bagola-core' ),
				'section' => 'Bagola_header_button_style_section',
			)
		);
		
		/*======  Price Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_price_color',
				'label' => esc_attr__( 'Price Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for price color.', 'Bagola-core' ),
				'section' => 'Bagola_header_button_style_section',
			)
		);
		
		/*======  Cart Icon Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff1ee',
				'settings' => 'Bagola_crt_bg_color',
				'label' => esc_attr__( 'Cart Icon Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_header_button_style_section',
			)
		);
		
		/*====== Cart Icon Border Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff1ee',
				'settings' => 'Bagola_crt_brdrcolor',
				'label' => esc_attr__( 'Cart Icon Border Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  border color.', 'Bagola-core' ),
				'section' => 'Bagola_header_button_style_section',
			)
		);
		
		/*======  Cart Icon  Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ea2b0f',
				'settings' => 'Bagola_crt_color',
				'label' => esc_attr__( 'Cart Icon Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for icon color.', 'Bagola-core' ),
				'section' => 'Bagola_header_button_style_section',
			)
		);
		
		/*======  Cart Count Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ea2b0f',
				'settings' => 'Bagola_crt_count_bg_color',
				'label' => esc_attr__( 'Cart Count Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_header_button_style_section',
			)
		);
		
		/*======  Cart Count Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_crt_count_color',
				'label' => esc_attr__( 'Cart Count Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_button_style_section',
			)
		);
		
		/*======  Sidebar Menu Main Title Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#2bbef9',
				'settings' => 'Bagola_sidebar_title_bg',
				'label' => esc_attr__( 'Sidebar Title Background', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		/*======  Sidebar Menu Main Title Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_sidebar_title_color',
				'label' => esc_attr__( 'Sidebar Title Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		/*======  Sidebar Menu Main Title Arrow Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_title_arrow_color',
				'label' => esc_attr__( 'Main Title Arrow Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		/*======  Sidebar Menu Second Main Title Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#edeef5',
				'settings' => 'Bagola_title_second_bg',
				'label' => esc_attr__( 'Second Main Title Background', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		/*======  Sidebar Menu Second Main Title Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#71778e',
				'settings' => 'Bagola_title_second_color',
				'label' => esc_attr__( 'Second Main Title Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		/*======  Sidebar Menu Second Main Title Border Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_title_second_brdrcolor',
				'label' => esc_attr__( 'Second Main Title Border Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		
		/*======  Sidebar Menu Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_sidebar_bg',
				'label' => esc_attr__( 'Sidebar Menu Background', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		/*======  Sidebar Menu Border Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#e4e5ee',
				'settings' => 'Bagola_sidebar_brdrcolor',
				'label' => esc_attr__( 'Sidebar Menu Border Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for border color.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		/*======  Sidebar Menu Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#3e445a',
				'settings' => 'Bagola_sidebar_color',
				'label' => esc_attr__( 'Sidebar Menu Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		/*======  Sidebar Menu Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#2bbef9',
				'settings' => 'Bagola_sidebar_hvrcolor',
				'label' => esc_attr__( 'Sidebar Menu Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_sidebar_menu_style_section',
			)
		);
		
		/*====== Sidebar Menu Typography ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'Bagola_header_sidebar_size',
				'label'       => esc_attr__( 'Sidebar Menu Typography', 'Bagola-core' ),
				'section'     => 'Bagola_header_sidebar_menu_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '13px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.menu-list li.link-parent > a , .site-header .all-categories > a ',
					],
				],
			)
		);
		
	/*====== Mobile Sidebar Menu Style ======*/	
		
		/*======  Mobile Sidebar Menu Header Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_mobile_sidebar_menu_header_color',
				'label' => esc_attr__( 'Mobile Sidebar Menu Header Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_mobile_sidebar_menu_style_section',
			)
		);
		
		/*======  Mobile Sidebar Menu Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#3e445a',
				'settings' => 'Bagola_mobile_sidebar_menu_color',
				'label' => esc_attr__( 'Mobile Sidebar Menu Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_mobile_sidebar_menu_style_section',
			)
		);
		
		/*======  Mobile Sidebar Menu Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#2bbef9',
				'settings' => 'Bagola_mobile_sidebar_menu_hvrcolor',
				'label' => esc_attr__( 'Mobile Sidebar Menu Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_mobile_sidebar_menu_style_section',
			)
		);
		
		/*======  Mobile Sidebar Menu Border Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#edeef5',
				'settings' => 'Bagola_mobile_sidebar_menu_brdrcolor',
				'label' => esc_attr__( 'Mobile Sidebar Menu Border Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for border color.', 'Bagola-core' ),
				'section' => 'Bagola_header_mobile_sidebar_menu_style_section',
			)
		);
		
		/*======  Mobile Sidebar Menu Copyright Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9bb4',
				'settings' => 'Bagola_mobile_sidebar_menu_copyright_color',
				'label' => esc_attr__( 'Mobile Sidebar Menu Copyright Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font-color.', 'Bagola-core' ),
				'section' => 'Bagola_header_mobile_sidebar_menu_style_section',
			)
		);

	/*====== SHOP ====================================================================================*/
		/*====== Shop Panels ======*/
		Kirki::add_panel (
			'Bagola_shop_panel',
			array(
				'title' => esc_html__( 'Shop Settings', 'Bagola-core' ),
				'description' => esc_html__( 'You can customize the shop from this panel.', 'Bagola-core' ),
			)
		);

		$sections = array (
			'shop_general' => array(
				esc_attr__( 'General', 'Bagola-core' ),
				esc_attr__( 'You can customize shop settings.', 'Bagola-core' )
			),
			
			'shop_single' => array(
				esc_attr__( 'Product Detail', 'Bagola-core' ),
				esc_attr__( 'You can customize the product single settings.', 'Bagola-core' )
			),
			
			'shop_banner' => array(
				esc_attr__( 'Banner', 'Bagola-core' ),
				esc_attr__( 'You can customize the banner.', 'Bagola-core' )
			),
			
			'mobile_menu' => array(
				esc_attr__( 'Mobile Bottom Menu Style ', 'Bagola-core' ),
				esc_attr__( 'You can customize the mobile menu.', 'Bagola-core' )
			),

			'my_account' => array(
				esc_attr__( 'My Account', 'Bagola-core' ),
				esc_attr__( 'You can customize the my account page.', 'Bagola-core' )
			),

			'free_shipping_bar' => array(
				esc_attr__( 'Free Shipping Bar ', 'Bagola-core' ),
				esc_attr__( 'You can customize the free shipping bar settings.', 'Bagola-core' )
			),
			
		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'Bagola_shop_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'Bagola_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}
		
		/*====== Shop Layouts ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'Bagola_shop_layout',
				'label' => esc_attr__( 'Layout', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose a layout for the shop.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => 'left-sidebar',
				'choices' => array(
					'left-sidebar' => esc_attr__( 'Left Sidebar', 'Bagola-core' ),
					'full-width' => esc_attr__( 'Full Width', 'Bagola-core' ),
					'right-sidebar' => esc_attr__( 'Right Sidebar', 'Bagola-core' ),
				),
			)
		);

		/*====== Shop Width ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'Bagola_shop_width',
				'label' => esc_attr__( 'Shop Page Width', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose a layout for the shop page.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => 'boxed',
				'choices' => array(
					'boxed' => esc_attr__( 'Boxed', 'Bagola-core' ),
					'wide' => esc_attr__( 'Wide', 'Bagola-core' ),
				),
			)
		);

		Bagola_customizer_add_field(
			array (
			'type'        => 'radio-buttonset',
			'settings'    => 'Bagola_product_box_type',
			'label'       => esc_html__( 'Shop Product Box Type', 'Bagola-core' ),
			'section'     => 'Bagola_shop_general_section',
			'default'     => 'type1',
			'priority'    => 10,
			'choices'     => array(
				'type1' => esc_attr__( 'Type 1', 'Bagola-core' ),
				'type2' => esc_attr__( 'Type 2', 'Bagola-core' ),
				'type4' => esc_attr__( 'Type 4', 'Bagola-core' ),
			),
			) 
		);

		Bagola_customizer_add_field(
			array (
			'type'        => 'radio-buttonset',
			'settings'    => 'Bagola_paginate_type',
			'label'       => esc_html__( 'Pagination Type', 'Bagola-core' ),
			'section'     => 'Bagola_shop_general_section',
			'default'     => 'default',
			'priority'    => 10,
			'choices'     => array(
				'default' => esc_attr__( 'Default', 'Bagola-core' ),
				'loadmore' => esc_attr__( 'Load More', 'Bagola-core' ),
				'infinite' => esc_attr__( 'Infinite', 'Bagola-core' ),
			),
			) 
		);
		
		/*====== Quantity Box Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_quantity_box',
				'label' => esc_attr__( 'Quantity Box', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable quantity box for the product box.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Ajax on Shop Page ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_ajax_on_shop',
				'label' => esc_attr__( 'Ajax on Shop Page', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable Ajax for the shop page.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Grid-List Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_grid_list_view',
				'label' => esc_attr__( 'Grid List View', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable grid list view on shop page.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Perpage Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_perpage_view',
				'label' => esc_attr__( 'Perpage View', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable perpage view on shop page.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Atrribute Swatches ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_attribute_swatches',
				'label' => esc_attr__( 'Attribute Swatches', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable the attribute types (Color - Button - Images).', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Quick View Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_quick_view_button',
				'label' => esc_attr__( 'Quick View Button', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the quick view button.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Wishlist Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_wishlist_button',
				'label' => esc_attr__( 'Custom Wishlist Button', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the wishlist button.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Ajax Notice Shop ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_notice_ajax_addtocart',
				'label' => esc_attr__( 'Added to Cart Ajax Notice', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the ajax notice feature.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Remove All Button ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_remove_all_button',
				'label' => esc_attr__( 'Remove All Button in cart page', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the remove all button.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Mobile Bottom Menu======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_mobile_bottom_menu',
				'label' => esc_attr__( 'Mobile Bottom Menu', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable the bottom menu on mobile.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Mobile Bottom Menu Edit Toggle======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_mobile_bottom_menu_edit_toggle',
				'label' => esc_attr__( 'Mobile Bottom Menu Edit', 'Bagola-core' ),
				'description' => esc_attr__( 'Edit the mobile bottom menu.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'Bagola_mobile_bottom_menu',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
				
			)
			
		);
		
		/*====== Mobile Menu Repeater ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'Bagola_mobile_bottom_menu_edit',
				'label' => esc_attr__( 'Mobile Bottom Menu Edit', 'Bagola-core' ),
				'description' => esc_attr__( 'Edit the mobile bottom menu.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'required' => array(
					array(
					  'setting'  => 'Bagola_mobile_bottom_menu_edit_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
				'fields' => array(
					'mobile_menu_type' => array(
						'type' => 'select',
						'label' => esc_attr__( 'Select Type', 'Bagola-core' ),
						'description' => esc_attr__( 'You can select a type', 'Bagola-core' ),
						'default' => 'default',
						'choices' => array(
							'default' => esc_attr__( 'Default', 'Bagola-core' ),
							'search' => esc_attr__( 'Search', 'Bagola-core' ),
							'filter' => esc_attr__( 'Filter', 'Bagola-core' ),
							'category' => esc_attr__( 'category', 'Bagola-core' ),
						),
					),
				
					'mobile_menu_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Icon', 'Bagola-core' ),
						'description' => esc_attr__( 'You can set an icon. for example; "store"', 'Bagola-core' ),
					),
					'mobile_menu_text' => array(
						'type' => 'text',
						'label' => esc_attr__( ' Text', 'Bagola-core' ),
						'description' => esc_attr__( 'You can enter a text.', 'Bagola-core' ),
					),
					'mobile_menu_url' => array(
						'type' => 'text',
						'label' => esc_attr__( 'URL', 'Bagola-core' ),
						'description' => esc_attr__( 'You can set url for the item.', 'Bagola-core' ),
					),
				),
				
			)
		);

		/*====== Product Stock Quantity ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_stock_quantity',
				'label' => esc_attr__( 'Stock Quantity', 'Bagola-core' ),
				'description' => esc_attr__( 'Show stock quantity on the label.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Product Min/Max Quantity ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_min_max_quantity',
				'label' => esc_attr__( 'Min/Max Quantity', 'Bagola-core' ),
				'description' => esc_attr__( 'Enable the additional quantity setting fields in product detail page.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Category Description ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_category_description_after_content',
				'label' => esc_attr__( 'Category Desc After Content', 'Bagola-core' ),
				'description' => esc_attr__( 'Add the category description after the products.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Catalog Mode - Disable Add to Cart ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_catalog_mode',
				'label' => esc_attr__( 'Catalog Mode', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable Add to Cart button on the shop page.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);	

		/*====== Recently Viewed Products ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_recently_viewed_products',
				'label' => esc_attr__( 'Recently Viewed Products', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable Recently Viewed Products.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);

		/*====== Recently Viewed Products Coulmn ======*/
		Bagola_customizer_add_field(
			array (
				'type'        => 'radio-buttonset',
				'settings'    => 'Bagola_recently_viewed_products_column',
				'label'       => esc_html__( 'Recently Viewed Products Column', 'Bagola-core' ),
				'section'     => 'Bagola_shop_general_section',
				'default'     => '4',
				'priority'    => 10,
				'choices'     => array(
					'6' => esc_attr__( '6', 'Bagola-core' ),
					'5' => esc_attr__( '5', 'Bagola-core' ),
					'4' => esc_attr__( '4', 'Bagola-core' ),
					'3' => esc_attr__( '3', 'Bagola-core' ),
					'2' => esc_attr__( '2', 'Bagola-core' ),
				),
				'required' => array(
					array(
					  'setting'  => 'Bagola_recently_viewed_products',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			) 
		);

		/*====== Min Order Amount ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_min_order_amount_toggle',
				'label' => esc_attr__( 'Min Order Amount', 'Bagola-core' ),
				'description' => esc_attr__( 'Enable Min Order Amount.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '0',
			)
		);
		
		/*====== Min Order Amount Value ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_min_order_amount_value',
				'label' => esc_attr__( 'Min Order Value', 'Bagola-core' ),
				'description' => esc_attr__( 'Set amount to specify a minimum order value.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_min_order_amount_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Product Image Size ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'dimensions',
				'settings' => 'Bagola_product_image_size',
				'label' => esc_attr__( 'Product Image Size', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set size of the product image for the shop page.', 'Bagola-core' ),
				'section' => 'Bagola_shop_general_section',
				'default' => array(
					'width' => '',
					'height' => '',
				),
			)
		);

		/*====== Shop Single Image Column ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'slider',
				'settings'    => 'Bagola_shop_single_image_column',
				'label'       => esc_html__( 'Image Column', 'Bagola-core' ),
				'section'     => 'Bagola_shop_single_section',
				'default'     => 5,
				'transport'   => 'auto',
				'choices'     => [
					'min'  => 3,
					'max'  => 12,
					'step' => 1,
				],
			)
		);

		/*====== Shop Single Type ======*/
		Bagola_customizer_add_field(
			array (
			'type'        => 'radio-buttonset',
			'settings'    => 'Bagola_single_type',
			'label'       => esc_html__( 'Type (Product Detail)', 'Bagola-core' ),
			'section'     => 'Bagola_shop_single_section',
			'default'     => 'type1',
			'priority'    => 10,
			'choices'     => array(
				'type1' => esc_attr__( 'Type 1', 'Bagola-core' ),
				'type2' => esc_attr__( 'Type 2', 'Bagola-core' ),
				'type3' => esc_attr__( 'Type 3', 'Bagola-core' ),
				'type4' => esc_attr__( 'Type 4', 'Bagola-core' ),
			),
			) 
		);
		
		/*====== Shop Single Gallery Type ======*/
		Bagola_customizer_add_field(
			array (
			'type'        => 'radio-buttonset',
			'settings'    => 'Bagola_single_gallery_type',
			'label'       => esc_html__( 'Gallery Type (Product Detail)', 'Bagola-core' ),
			'section'     => 'Bagola_shop_single_section',
			'default'     => 'horizontal',
			'priority'    => 10,
			'choices'     => array(
				'horizontal' => esc_attr__( 'Horizontal', 'Bagola-core' ),
				'vertical' => esc_attr__( 'Vertical', 'Bagola-core' ),
			),
			) 
		);

		/*====== Shop Single Full width ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_single_full_width',
				'label' => esc_attr__( 'Full Width', 'Bagola-core' ),
				'description' => esc_attr__( 'Stretch the single product page content.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Shop Single Image Zoom  ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_single_image_zoom',
				'label' => esc_attr__( 'Image Zoom', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the zoom feature.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Product360 View ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_single_product360',
				'label' => esc_attr__( 'Product360 View', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable Product 360 View.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);
		
		/*====== Shop Single Compare  ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_compare_button',
				'label' => esc_attr__( 'Compare', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the compare button.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Shop Single Ajax Add To Cart ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_single_ajax_addtocart',
				'label' => esc_attr__( 'Ajax Add to Cart', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable ajax add to cart button.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*======  Sticky Single Cart ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_single_sticky_cart',
				'label' => esc_attr__( 'Sticky Add to Cart', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable the sticky add to cart section.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Single Sticky Titles ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_single_sticky_titles',
				'label' => esc_attr__( 'Sticky Titles', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable the sticky titles for desktop.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Mobile Sticky Single Cart ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_mobile_single_sticky_cart',
				'label' => esc_attr__( 'Mobile Sticky Add to Cart', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable sticky cart button on mobile.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Buy Now Single ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_single_buy_now',
				'label' => esc_attr__( 'Buy Now Button', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable Buy Now button.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Shop Products Navigation  ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_products_navigation',
				'label' => esc_attr__( 'Products Navigation', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Related By Tags ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_related_by_tags',
				'label' => esc_attr__( 'Related Products with Tags', 'Bagola-core' ),
				'description' => esc_attr__( 'Display the related products by tags.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Single Product Stock Progress Bar ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_single_stock_progress_bar',
				'label' => esc_attr__( 'Stock Progress Bar', 'Bagola-core' ),
				'description' => esc_attr__( 'Display the stock progress bar if stock management is enabled.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);
		
		/*====== Single Product Time Countdown ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_single_time_countdown',
				'label' => esc_attr__( 'Time Countdown', 'Bagola-core' ),
				'description' => esc_attr__( 'Display the sale time countdown.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Order on WhatsApp ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_single_orderonwhatsapp',
				'label' => esc_attr__( 'Order on WhatsApp', 'Bagola-core' ),
				'description' => esc_attr__( 'Enable the button on the product detail page.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);
		
		/*====== Order on WhatsApp Number======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_shop_single_whatsapp_number',
				'label' => esc_attr__( 'WhatsApp Number', 'Bagola-core' ),
				'description' => esc_attr__( 'You can add a phone number for order on WhatsApp.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_shop_single_orderonwhatsapp',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Move Review Tab ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_single_review_tab_move',
				'label' => esc_attr__( 'Move Review Tab', 'Bagola-core' ),
				'description' => esc_attr__( 'Move the review tab out of tabs', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Shop Single Social Share ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_social_share',
				'label' => esc_attr__( 'Social Share (Product Detail)', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable social share buttons.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Shop Single Social Share ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'multicheck',
				'settings'    => 'Bagola_shop_single_share',
				'section'     => 'Bagola_shop_single_section',
				'default'     => array('facebook','twitter', 'pinterest', 'linkedin', 'reddit', 'whatsapp'  ),
				'priority'    => 10,
				'choices'     => [
					'facebook'  => esc_html__( 'Facebook', 	'Bagola-core' ),
					'twitter' 	=> esc_html__( 'Twitter', 	'Bagola-core' ),
					'pinterest' => esc_html__( 'Pinterest', 'Bagola-core' ),
					'linkedin'  => esc_html__( 'Linkedin', 	'Bagola-core' ),
					'reddit'  	=> esc_html__( 'Reddit', 	'Bagola-core' ),
					'whatsapp'  => esc_html__( 'Whatsapp', 	'Bagola-core' ),
				],
				'required' => array(
					array(
					  'setting'  => 'Bagola_shop_social_share',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		

		/*====== Shop Single Featured Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_shop_single_featured_toggle',
				'label' => esc_attr__( 'Featured List', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable the featured list.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '0',
			)
		);

		/*====== Shop Single Featured Title ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_shop_single_featured_title',
				'label' => esc_attr__( 'Set Title', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a title.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_shop_single_featured_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Shop Single Featured List ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'Bagola_single_featured_list',
				'label' => esc_attr__( 'Featured List', 'Bagola-core' ),
				'description' => esc_attr__( 'You can create the featured list.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'row_label' => array (
					'type' => 'field',
					'field' => 'link_text',
				),
				'required' => array(
					array(
					  'setting'  => 'Bagola_shop_single_featured_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
				'fields' => array(
					'featured_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Featured Icon', 'Bagola-core' ),
						'description' => esc_attr__( 'Icon example; klbth-icon-dollar.', 'Bagola-core' ),
					),
					'featured_text' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Featured Content', 'Bagola-core' ),
						'description' => esc_attr__( 'You can enter a text.', 'Bagola-core' ),
					),
				),
			)
		);

		/*====== Product Related Post Column ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'Bagola_shop_related_post_column',
				'label' => esc_attr__( 'Related Post Column', 'Bagola-core' ),
				'description' => esc_attr__( 'You can control related post column with this option.', 'Bagola-core' ),
				'section' => 'Bagola_shop_single_section',
				'default' => '4',
				'choices' => array(
					'5' => esc_attr__( '5 Columns', 'Bagola-core' ),
					'4' => esc_attr__( '4 Columns', 'Bagola-core' ),
					'3' => esc_attr__( '3 Columns', 'Bagola-core' ),
					'2' => esc_attr__( '2 Columns', 'Bagola-core' ),
				),
			)
		);

		
		/*====== Shop Banner Image======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'Bagola_shop_banner_image',
				'label' => esc_attr__( 'Image', 'Bagola-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'Bagola-core' ),
				'section' => 'Bagola_shop_banner_section',
				'choices' => array(
					'save_as' => 'id',
				),
			)
		);
		
		/*====== Shop Banner Title ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_shop_banner_title',
				'label' => esc_attr__( 'Set Title', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a title.', 'Bagola-core' ),
				'section' => 'Bagola_shop_banner_section',
				'default' => '',
			)
		);
		
		/*====== Shop Banner Subtitle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'Bagola_shop_banner_subtitle',
				'label' => esc_attr__( 'Set Subtitle', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a subtitle.', 'Bagola-core' ),
				'section' => 'Bagola_shop_banner_section',
				'default' => '',
			)
		);
		
		/*====== Shop Banner Desc ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_shop_banner_desc',
				'label' => esc_attr__( 'Description', 'Bagola-core' ),
				'description' => esc_attr__( 'Add a description.', 'Bagola-core' ),
				'section' => 'Bagola_shop_banner_section',
				'default' => '',
			)
		);

		/*====== Shop Banner URL ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_shop_banner_button_url',
				'label' => esc_attr__( 'Set URL', 'Bagola-core' ),
				'description' => esc_attr__( 'Set an url for the button', 'Bagola-core' ),
				'section' => 'Bagola_shop_banner_section',
				'default' => '#',
			)
		);
		

		/*====== Banner Repeater For each category ======*/
		add_action( 'init', function() {
			Bagola_customizer_add_field (
				array(
					'type' => 'repeater',
					'settings' => 'Bagola_shop_banner_each_category',
					'label' => esc_attr__( 'Banner For Categories', 'Bagola-core' ),
					'description' => esc_attr__( 'You can set banner for each category.', 'Bagola-core' ),
					'section' => 'Bagola_shop_banner_section',
					'fields' => array(
						
						'category_id' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Select Category', 'Bagola-core' ),
							'description' => esc_html__( 'Set a category', 'Bagola-core' ),
							'priority'    => 10,
							'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'product_cat') )
						),
						
						'category_image' =>  array(
							'type' => 'image',
							'label' => esc_attr__( 'Image', 'Bagola-core' ),
							'description' => esc_attr__( 'You can upload an image.', 'Bagola-core' ),
						),
						
						'category_title' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Set Title', 'Bagola-core' ),
							'description' => esc_attr__( 'You can set a title.', 'Bagola-core' ),
						),
						
						'category_subtitle' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Set Subtitle', 'Bagola-core' ),
							'description' => esc_attr__( 'You can set a subtitle.', 'Bagola-core' ),
						),
			
						'category_desc' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Description', 'Bagola-core' ),
							'description' => esc_attr__( 'Add a description.', 'Bagola-core' ),
						),
						
						'category_button_url' => array(
							'type' => 'text',
							'label' => esc_attr__( 'Set URL', 'Bagola-core' ),
							'description' => esc_attr__( 'Set an url for the button', 'Bagola-core' ),
						),
					),
				)
			);
		} );
		
		/*======  Mobile Menu Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_mobile_menu_bg_color',
				'label' => esc_attr__( 'Mobile Menu Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a Background.', 'Bagola-core' ),
				'section' => 'Bagola_mobile_menu_section',
			)
		);
		
		/*======  Mobile Menu Icon Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#a7a7b5',
				'settings' => 'Bagola_mobile_menu_icon_color',
				'label' => esc_attr__( 'Mobile Menu Icon Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color.', 'Bagola-core' ),
				'section' => 'Bagola_mobile_menu_section',
			)
		);
		
		/*======  Mobile Menu Icon Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#a7a7b5',
				'settings' => 'Bagola_mobile_menu_icon_hvrcolor',
				'label' => esc_attr__( 'Mobile Menu Icon Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color.', 'Bagola-core' ),
				'section' => 'Bagola_mobile_menu_section',
			)
		);
		
		/*======  Mobile Menu Font Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#a7a7b5',
				'settings' => 'Bagola_mobile_menu_color',
				'label' => esc_attr__( 'Mobile Menu Font Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color.', 'Bagola-core' ),
				'section' => 'Bagola_mobile_menu_section',
			)
		);
		
		/*======  Mobile Menu Font Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#a7a7b5',
				'settings' => 'Bagola_mobile_menu_hvr_color',
				'label' => esc_attr__( 'Mobile Menu Font Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color.', 'Bagola-core' ),
				'section' => 'Bagola_mobile_menu_section',
			)
		);
		
		/*====== Mobile Menu Font Style ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'Bagola_mobile_menu_size',
				'label'       => esc_attr__( 'Mobile Menu Font Style', 'Bagola-core' ),
				'section'     => 'Bagola_mobile_menu_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '10px',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-header .header-mobile-nav .menu-item a span',
					],
				],		
			)
		);

		/*====== My Account Layouts ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'Bagola_my_account_layout',
				'label' => esc_attr__( 'Layout', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose a layout for the login form.', 'Bagola-core' ),
				'section' => 'Bagola_my_account_section',
				'default' => 'default',
				'choices' => array(
					'default' => esc_attr__( 'Default', 'Bagola-core' ),
					'logintab' => esc_attr__( 'Login Tab', 'Bagola-core' ),
				),
			)
		);

		/*====== Registration Form First Name ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'Bagola_registration_first_name',
				'label' => esc_attr__( 'Register - First Name', 'Bagola-core' ),
				'section' => 'Bagola_my_account_section',
				'default' => 'hidden',
				'choices' => array(
					'hidden' => esc_attr__( 'Hidden', 'Bagola-core' ),
					'visible' => esc_attr__( 'Visible', 'Bagola-core' ),
					'optional' => esc_attr__( 'Optional', 'Bagola-core' ),
				),
			)
		);
		
		/*====== Registration Form Last Name ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'Bagola_registration_last_name',
				'label' => esc_attr__( 'Register - Last Name', 'Bagola-core' ),
				'section' => 'Bagola_my_account_section',
				'default' => 'hidden',
				'choices' => array(
					'hidden' => esc_attr__( 'Hidden', 'Bagola-core' ),
					'visible' => esc_attr__( 'Visible', 'Bagola-core' ),
					'optional' => esc_attr__( 'Optional', 'Bagola-core' ),
				),
			)
		);
		
		/*====== Registration Form Billing Company ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'Bagola_registration_billing_company',
				'label' => esc_attr__( 'Register - Billing Company', 'Bagola-core' ),
				'section' => 'Bagola_my_account_section',
				'default' => 'hidden',
				'choices' => array(
					'hidden' => esc_attr__( 'Hidden', 'Bagola-core' ),
					'visible' => esc_attr__( 'Visible', 'Bagola-core' ),
					'optional' => esc_attr__( 'Optional', 'Bagola-core' ),
				),
			)
		);
		
		/*====== Registration Form Billing Phone ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'Bagola_registration_billing_phone',
				'label' => esc_attr__( 'Register - Billing Phone', 'Bagola-core' ),
				'section' => 'Bagola_my_account_section',
				'default' => 'hidden',
				'choices' => array(
					'hidden' => esc_attr__( 'Hidden', 'Bagola-core' ),
					'visible' => esc_attr__( 'Visible', 'Bagola-core' ),
					'optional' => esc_attr__( 'Optional', 'Bagola-core' ),
				),
			)
		);

		/*====== Ajax Login-Register ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_ajax_login_form',
				'label' => esc_attr__( 'Activate Ajax for Login Form', 'Bagola-core' ),
				'section' => 'Bagola_my_account_section',
				'default' => '0',
			)
		);

		/*====== Redirect URL After Login ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'url',
				'settings' => 'Bagola_redirect_url_after_login',
				'label' => esc_attr__( 'Redirect URL After Login', 'Bagola-core' ),
				'section' => 'Bagola_my_account_section',
				'default' => '',
			)
		);
		

	/*====== Free Shipping Settings =======================================================*/
	
		/*====== Free Shipping ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_free_shipping',
				'label' => esc_attr__( 'Free shipping bar', 'Bagola-core' ),
				'section' => 'Bagola_free_shipping_bar_section',
				'default' => '0',
			)
		);
		
		/*====== Free Shipping Goal Amount ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'shipping_progress_bar_amount',
				'label' => esc_attr__( 'Goal Amount', 'Bagola-core' ),
				'description' => esc_attr__( 'Amount to reach 100% defined in your currency absolute value. For example: 300', 'Bagola-core' ),
				'section' => 'Bagola_free_shipping_bar_section',
				'default' => '100',
				'required' => array(
					array(
					  'setting'  => 'Bagola_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Location Cart Page ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'shipping_progress_bar_location_card_page',
				'label' => esc_attr__( 'Cart page', 'Bagola-core' ),
				'section' => 'Bagola_free_shipping_bar_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'Bagola_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Location Mini cart ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'shipping_progress_bar_location_mini_cart',
				'label' => esc_attr__( 'Mini cart', 'Bagola-core' ),
				'section' => 'Bagola_free_shipping_bar_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'Bagola_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Location Checkout page ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'shipping_progress_bar_location_checkout',
				'label' => esc_attr__( 'Checkout page', 'Bagola-core' ),
				'section' => 'Bagola_free_shipping_bar_section',
				'default' => '0',
				'required' => array(
					array(
					  'setting'  => 'Bagola_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Message Initial ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'shipping_progress_bar_message_initial',
				'label' => esc_attr__( 'Initial Message', 'Bagola-core' ),
				'description' => esc_attr__( 'Message to show before reaching the goal. Use shortcode [remainder] to display the amount left to reach the minimum.', 'Bagola-core' ),
				'section' => 'Bagola_free_shipping_bar_section',
				'default' => 'Add [remainder] to cart and get free shipping!',
				'required' => array(
					array(
					  'setting'  => 'Bagola_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Free Shipping Message Success ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'shipping_progress_bar_message_success',
				'label' => esc_attr__( 'Success message', 'Bagola-core' ),
				'description' => esc_attr__( 'Message to show after reaching 100%.', 'Bagola-core' ),
				'section' => 'Bagola_free_shipping_bar_section',
				'default' => 'Your order qualifies for free shipping!',
				'required' => array(
					array(
					  'setting'  => 'Bagola_free_shipping',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

	/*====== Blog Settings =======================================================*/
		/*====== Layouts ======*/
		
		Bagola_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'Bagola_blog_layout',
				'label' => esc_attr__( 'Layout', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose a layout.', 'Bagola-core' ),
				'section' => 'Bagola_blog_settings_section',
				'default' => 'right-sidebar',
				'choices' => array(
					'left-sidebar' => esc_attr__( 'Left Sidebar', 'Bagola-core' ),
					'full-width' => esc_attr__( 'Full Width', 'Bagola-core' ),
					'right-sidebar' => esc_attr__( 'Right Sidebar', 'Bagola-core' ),
				),
			)
		);
		
		/*====== Main color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#233a95',
				'settings' => 'Bagola_main_color',
				'label' => esc_attr__( 'Main Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can customize the main color.', 'Bagola-core' ),
				'section' => 'Bagola_main_color_section',
			)
		);

		/*====== Secondary color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#2bbef9',
				'settings' => 'Bagola_second_color',
				'label' => esc_attr__( 'Second Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can customize the secondary color.', 'Bagola-core' ),
				'section' => 'Bagola_main_color_section',
			)
		);

		/*====== Price Font color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#d51243',
				'settings' => 'Bagola_price_font_color',
				'label' => esc_attr__( 'Price Font Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can customize the price font color.', 'Bagola-core' ),
				'section' => 'Bagola_main_color_section',
			)
		);

		/*====== Color Danger ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ed174a',
				'settings' => 'Bagola_color_danger',
				'label' => esc_attr__( 'Color Danger', 'Bagola-core' ),
				'description' => esc_attr__( 'You can customize the color danger.', 'Bagola-core' ),
				'section' => 'Bagola_main_color_section',
			)
		);
		
		/*====== Color Danger Dark======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#be143c',
				'settings' => 'Bagola_color_danger_dark',
				'label' => esc_attr__( 'Color Danger Dark', 'Bagola-core' ),
				'description' => esc_attr__( 'You can customize the color danger dark.', 'Bagola-core' ),
				'section' => 'Bagola_main_color_section',
			)
		);
		
		/*====== Color Success======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#00b853',
				'settings' => 'Bagola_color_success',
				'label' => esc_attr__( 'Color Success', 'Bagola-core' ),
				'description' => esc_attr__( 'You can customize the color success.', 'Bagola-core' ),
				'section' => 'Bagola_main_color_section',
			)
		);
		
		/*====== Color Rating======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#ffcd00',
				'settings' => 'Bagola_color_rating',
				'label' => esc_attr__( 'Color Rating', 'Bagola-core' ),
				'description' => esc_attr__( 'You can customize the color rating.', 'Bagola-core' ),
				'section' => 'Bagola_main_color_section',
			)
		);

	/*====== Elementor Templates =======================================================*/
		/*====== Before Shop Elementor Templates ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'Bagola_before_main_shop_elementor_template',
				'label'       => esc_html__( 'Before Shop Elementor Template', 'Bagola-core' ),
				'section'     => 'Bagola_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates ', 'Bagola-core' ),
				'choices'     => Bagola_get_elementorTemplates('section'),
				
			)
		);
		
		/*====== After Shop Elementor Templates ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'Bagola_after_main_shop_elementor_template',
				'label'       => esc_html__( 'After Shop Elementor Template', 'Bagola-core' ),
				'section'     => 'Bagola_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates ', 'Bagola-core' ),
				'choices'     => Bagola_get_elementorTemplates('section'),
				
			)
		);
		
		/*====== Before Header Elementor Templates ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'Bagola_before_main_header_elementor_template',
				'label'       => esc_html__( 'Before Header Elementor Template', 'Bagola-core' ),
				'section'     => 'Bagola_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'Bagola-core' ),
				'choices'     => Bagola_get_elementorTemplates('section'),
				
			)
		);
	
		/*====== After Header Elementor Templates ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'Bagola_after_main_header_elementor_template',
				'label'       => esc_html__( 'After Header Elementor Template', 'Bagola-core' ),
				'section'     => 'Bagola_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates ', 'Bagola-core' ),
				'choices'     => Bagola_get_elementorTemplates('section'),
				
			)
		);
		
		/*====== Before Footer Elementor Template ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'Bagola_before_main_footer_elementor_template',
				'label'       => esc_html__( 'Before Footer Elementor Template', 'Bagola-core' ),
				'section'     => 'Bagola_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'Bagola-core' ),
				'choices'     => Bagola_get_elementorTemplates('section'),
				
			)
		);
		
		/*====== After Footer Elementor  Template ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'select',
				'settings'    => 'Bagola_after_main_footer_elementor_template',
				'label'       => esc_html__( 'After Footer Elementor Templates', 'Bagola-core' ),
				'section'     => 'Bagola_elementor_templates_section',
				'default'     => '',
				'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'Bagola-core' ),
				'choices'     => Bagola_get_elementorTemplates('section'),
				
			)
		);

		/*====== Templates Repeater For each category ======*/
		add_action( 'init', function() {
			Bagola_customizer_add_field (
				array(
					'type' => 'repeater',
					'settings' => 'Bagola_elementor_template_each_shop_category',
					'label' => esc_attr__( 'Template For Categories', 'Bagola-core' ),
					'description' => esc_attr__( 'You can set template for each category.', 'Bagola-core' ),
					'section' => 'Bagola_elementor_templates_section',
					'fields' => array(
						
						'category_id' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Select Category', 'Bagola-core' ),
							'description' => esc_html__( 'Set a category', 'Bagola-core' ),
							'priority'    => 10,
							'default'     => '',
							'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'product_cat') )
						),
						
						'Bagola_before_main_shop_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Before Shop Elementor Template', 'Bagola-core' ),
							'choices'     => Bagola_get_elementorTemplates('section'),
							'default'     => '',
							'placeholder' => esc_html__( 'Select a template from elementor templates, If you want to show any content before products ', 'Bagola-core' ),
						),
						
						'Bagola_after_main_shop_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'After Shop Elementor Template', 'Bagola-core' ),
							'choices'     => Bagola_get_elementorTemplates('section'),
						),
						
						'Bagola_before_main_header_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Before Header Elementor Template', 'Bagola-core' ),
							'choices'     => Bagola_get_elementorTemplates('section'),
						),
						
						'Bagola_after_main_header_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'After Header Elementor Template', 'Bagola-core' ),
							'choices'     => Bagola_get_elementorTemplates('section'),
						),
						
						'Bagola_before_main_footer_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'Before Footer Elementor Template', 'Bagola-core' ),
							'choices'     => Bagola_get_elementorTemplates('section'),
						),
						
						'Bagola_after_main_footer_elementor_template_category' => array(
							'type'        => 'select',
							'label'       => esc_html__( 'After Footer Elementor Template', 'Bagola-core' ),
							'choices'     => Bagola_get_elementorTemplates('section'),
						),
						

					),
				)
			);
		} );


		/*====== Map Settings ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_mapapi',
				'label' => esc_attr__( 'Google Map Api key', 'Bagola-core' ),
				'description' => esc_attr__( 'Add your google map api key', 'Bagola-core' ),
				'section' => 'Bagola_map_settings_section',
				'default' => '',
			)
		);
		
	/*====== Bagola Widgets ======*/
		/*====== Widgets Panels ======*/
		Kirki::add_panel (
			'Bagola_widgets_panel',
			array(
				'title' => esc_html__( 'Bagola Widgets', 'Bagola-core' ),
				'description' => esc_html__( 'You can customize the Bagola widgets.', 'Bagola-core' ),
			)
		);

		$sections = array (
			
			'social_list' => array(
				esc_attr__( 'Social List', 'Bagola-core' ),
				esc_attr__( 'You can customize the social list widget.', 'Bagola-core' )
			),
		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'Bagola_widgets_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'Bagola_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}

		/*====== Social List Widget ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'Bagola_social_list_widget',
				'label' => esc_attr__( 'Social List Widget', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set social icons.', 'Bagola-core' ),
				'section' => 'Bagola_social_list_section',
				'fields' => array(
					'social_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Icon', 'Bagola-core' ),
						'description' => esc_attr__( 'You can set an icon. for example; "facebook"', 'Bagola-core' ),
					),

					'social_url' => array(
						'type' => 'text',
						'label' => esc_attr__( 'URL', 'Bagola-core' ),
						'description' => esc_attr__( 'You can set url for the item.', 'Bagola-core' ),
					),

				),
			)
		);
		
	/*====== Footer ======*/
		/*====== Footer Panels ======*/
		Kirki::add_panel (
			'Bagola_footer_panel',
			array(
				'title' => esc_html__( 'Footer Settings', 'Bagola-core' ),
				'description' => esc_html__( 'You can customize the footer from this panel.', 'Bagola-core' ),
			)
		);

		$sections = array (
			'footer_subscribe' => array(
				esc_attr__( 'Subscribe', 'Bagola-core' ),
				esc_attr__( 'You can customize the subscribe area.', 'Bagola-core' )
			),
			
			'footer_featured_box' => array(
				esc_attr__( 'Featured Box', 'Bagola-core' ),
				esc_attr__( 'You can customize the featured box section.', 'Bagola-core' )
			),
			
			'footer_contact' => array(
				esc_attr__( 'Contact Details', 'Bagola-core' ),
				esc_attr__( 'You can customize the contact details section.', 'Bagola-core' )
			),
			
			'footer_general' => array(
				esc_attr__( 'Footer General', 'Bagola-core' ),
				esc_attr__( 'You can customize the footer settings.', 'Bagola-core' )
			),
			
			'footer_style' => array(
				esc_attr__( 'Footer Style', 'Bagola-core' ),
				esc_attr__( 'You can customize the footer settings.', 'Bagola-core' )
			),
			
		);

		foreach ( $sections as $section_id => $section ) {
			$section_args = array(
				'title' => $section[0],
				'description' => $section[1],
				'panel' => 'Bagola_footer_panel',
			);

			if ( isset( $section[2] ) ) {
				$section_args['type'] = $section[2];
			}

			Kirki::add_section( 'Bagola_' . str_replace( '-', '_', $section_id ) . '_section', $section_args );
		}

		
		/*====== Subcribe Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_footer_subscribe_area',
				'label' => esc_attr__( 'Subcribe', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable subscribe section.', 'Bagola-core' ),
				'section' => 'Bagola_footer_subscribe_section',
				'default' => '0',
			)
		);
		
		/*====== Subcribe FORM ID======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_footer_subscribe_formid',
				'label' => esc_attr__( 'Subscribe Form Id.', 'Bagola-core' ),
				'description' => esc_attr__( 'You can find the form id in Dashboard > Mailchimp For Wp > Form.', 'Bagola-core' ),
				'section' => 'Bagola_footer_subscribe_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_subscribe_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subscribe Title ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'Bagola_footer_subscribe_title',
				'label' => esc_attr__( 'Title', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set text for subscribe section.', 'Bagola-core' ),
				'section' => 'Bagola_footer_subscribe_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_subscribe_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subscribe Subtitle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_footer_subscribe_subtitle',
				'label' => esc_attr__( 'Subtitle', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set text for subscribe section.', 'Bagola-core' ),
				'section' => 'Bagola_footer_subscribe_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_subscribe_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subscribe Desc ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'Bagola_footer_subscribe_desc',
				'label' => esc_attr__( 'Description', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set text for subscribe section.', 'Bagola-core' ),
				'section' => 'Bagola_footer_subscribe_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_subscribe_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subscribe Image ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'Bagola_footer_subscribe_image',
				'label' => esc_attr__( 'Image', 'Bagola-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'Bagola-core' ),
				'section' => 'Bagola_footer_subscribe_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_subscribe_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subscribe Typography ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'Bagola_subscribe_size',
				'label'       => esc_attr__( 'Subscribe Typography', 'Bagola-core' ),
				'section'     => 'Bagola_footer_subscribe_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-footer .footer-subscribe .subscribe-content , .site-footer .footer-subscribe .entry-subtitle , .site-footer .footer-subscribe .entry-title , .site-footer .footer-subscribe .entry-teaser p',
					],
				],
			)
		);
		
		/*====== Subscribe Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#233a95',
				'settings' => 'Bagola_subscribe_bg',
				'label' => esc_attr__( 'Subscribe Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_footer_subscribe_section',
			)
		);
		
		/*====== Subscribe  Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_subscribe_color',
				'label' => esc_attr__( 'Subscribe  Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_subscribe_section',
			)
		);
		
		/*====== Subscribe Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_subscribe_hvrcolor',
				'label' => esc_attr__( 'Subscribe Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_subscribe_section',
			)
		);
		
		/*====== Featured Box ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'Bagola_footer_featured_box',
				'label' => esc_attr__( 'Featured Box', 'Bagola-core' ),
				'description' => esc_attr__( 'You can create featured box.', 'Bagola-core' ),
				'section' => 'Bagola_footer_featured_box_section',
				'fields' => array(
					'featured_text' => array(
						'type' => 'textarea',
						'label' => esc_attr__( 'Featured Content', 'Bagola-core' ),
						'description' => esc_attr__( 'You can enter a text.', 'Bagola-core' ),
					),
					
					'featured_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Featured Icon', 'Bagola-core' ),
						'description' => esc_attr__( 'set an icon.', 'Bagola-core' ),
					),
				),
			)
		);
		
		/*====== Contact Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_footer_contact_area',
				'label' => esc_attr__( 'Contact Section', 'Bagola-core' ),
				'description' => esc_attr__( 'Disable or Enable the contact section.', 'Bagola-core' ),
				'section' => 'Bagola_footer_contact_section',
				'default' => '0',
			)
		);
		
		/*====== Contact Phone Icon======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_footer_phone_icon',
				'label' => esc_attr__( 'Phone Icon', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set an icon.', 'Bagola-core' ),
				'section' => 'Bagola_footer_contact_section',
				'default' => 'klbth-icon-phone-call',
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_contact_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Contact Phone Title======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_footer_phone_title',
				'label' => esc_attr__( 'Phone Title', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a title.', 'Bagola-core' ),
				'section' => 'Bagola_footer_contact_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_contact_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Contact Phone Subtitle======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_footer_phone_subtitle',
				'label' => esc_attr__( 'Phone Subtitle', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a subtitle.', 'Bagola-core' ),
				'section' => 'Bagola_footer_contact_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_contact_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Contact APP Title======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_footer_app_title',
				'label' => esc_attr__( 'APP Title', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a title.', 'Bagola-core' ),
				'section' => 'Bagola_footer_contact_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_contact_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Contact APP Subtitle======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_footer_app_subtitle',
				'label' => esc_attr__( 'APP Subtitle', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a subtitle.', 'Bagola-core' ),
				'section' => 'Bagola_footer_contact_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_contact_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Contact APP Image ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'Bagola_footer_app_image',
				'label' => esc_attr__( 'APP IMAGE', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set the app images.', 'Bagola-core' ),
				'section' => 'Bagola_footer_contact_section',
				'fields' => array(
					'app_image' => array(
						'type' => 'image',
						'label' => esc_attr__( 'Image', 'Bagola-core' ),
						'description' => esc_attr__( 'You can upload an image.', 'Bagola-core' ),
					),
					
					'app_url' => array(
						'type' => 'text',
						'label' => esc_attr__( 'URL', 'Bagola-core' ),
						'description' => esc_attr__( 'set an url for the image.', 'Bagola-core' ),
					),
				),
				'required' => array(
					array(
					  'setting'  => 'Bagola_footer_contact_area',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Contact Social List ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'repeater',
				'settings' => 'Bagola_footer_social_list',
				'label' => esc_attr__( 'Social List', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set social icons.', 'Bagola-core' ),
				'section' => 'Bagola_footer_contact_section',
				'fields' => array(
					'social_icon' => array(
						'type' => 'text',
						'label' => esc_attr__( 'Icon', 'Bagola-core' ),
						'description' => esc_attr__( 'You can set an icon. for example; "facebook"', 'Bagola-core' ),
					),

					'social_url' => array(
						'type' => 'text',
						'label' => esc_attr__( 'URL', 'Bagola-core' ),
						'description' => esc_attr__( 'You can set url for the item.', 'Bagola-core' ),
					),

				),
			)
		);
		
		/*====== Copyright ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_copyright',
				'label' => esc_attr__( 'Copyright', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a copyright text for the footer.', 'Bagola-core' ),
				'section' => 'Bagola_footer_general_section',
				'default' => '',
			)
		);
		
		/*====== Subscribe Image ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'Bagola_footer_payment_image',
				'label' => esc_attr__( 'Image', 'Bagola-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'Bagola-core' ),
				'section' => 'Bagola_footer_general_section',
				'choices' => array(
					'save_as' => 'id',
				),
			)
		);

		/*====== Payment Image URL ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_footer_payment_image_url',
				'label' => esc_attr__( 'Set Payment URL', 'Bagola-core' ),
				'description' => esc_attr__( 'Set an url for the payment image', 'Bagola-core' ),
				'section' => 'Bagola_footer_general_section',
				'default' => '#',
			)
		);

		/*====== Footer Column ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'select',
				'settings' => 'Bagola_footer_column',
				'label' => esc_attr__( 'Footer Column', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set footer column.', 'Bagola-core' ),
				'section' => 'Bagola_footer_general_section',
				'default' => '5columns',
				'choices' => array(
					'6columns' => esc_attr__( '6 Columns', 'Bagola-core' ),
					'5columns' => esc_attr__( '5 Columns', 'Bagola-core' ),
					'4columns' => esc_attr__( '4 Columns', 'Bagola-core' ),
					'3columns' => esc_attr__( '3 Columns', 'Bagola-core' ),
				),
			)
		);
		
		/*======Footer Menu Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_footer_menu',
				'label' => esc_attr__( 'Footer Menu', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of the footer menu on the footer.', 'Bagola-core' ),
				'section' => 'Bagola_footer_general_section',
				'default' => '0',
			)
		);
		
		/*====== Back to top  ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_scroll_to_top',
				'label' => esc_attr__( 'Back To Top Button', 'Bagola' ),
				'section' => 'Bagola_footer_general_section',
				'default' => '0',
			)
		);
		
		
		/*====== Footer Featured Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#f7f8fd',
				'settings' => 'Bagola_featured_bg_color',
				'label' => esc_attr__( 'Footer Featured Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);

		/*====== Footer Featured Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#000000',
				'settings' => 'Bagola_featured_color',
				'label' => esc_attr__( 'Footer Featured Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Featured Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#000000',
				'settings' => 'Bagola_featured_hvrcolor',
				'label' => esc_attr__( 'Footer Featured Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#f7f8fd',
				'settings' => 'Bagola_footer_bg_color',
				'label' => esc_attr__( 'Footer Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  background.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);

		/*====== Footer Header Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_footer_header_color',
				'label' => esc_attr__( 'Footer Header Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Header Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_footer_header_hvrcolor',
				'label' => esc_attr__( 'Footer Header Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#71778e',
				'settings' => 'Bagola_footer_color',
				'label' => esc_attr__( 'Footer Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#71778e',
				'settings' => 'Bagola_footer_hvrcolor',
				'label' => esc_attr__( 'Footer Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Phone Icon Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_footer_phone_icon_bg',
				'label' => esc_attr__( 'Footer Phone Icon Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Phone Icon Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_footer_phone_icon_color',
				'label' => esc_attr__( 'Footer Phone Icon Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Contact Background ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_footer_contact_background',
				'label' => esc_attr__( 'Footer Contact Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Contact Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_footer_contact_phone_color',
				'label' => esc_attr__( 'Footer Contact Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Contact Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_footer_contact_phone_hvrcolor',
				'label' => esc_attr__( 'Footer Contact Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Contact Second Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_footer_contact_color',
				'label' => esc_attr__( 'Footer Contact Second Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Contact Second Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#202435',
				'settings' => 'Bagola_footer_contact_hvrcolor',
				'label' => esc_attr__( 'Footer Contact Second Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Social Icon Background Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_footer_social_icon_bg',
				'label' => esc_attr__( 'Footer Social Icon Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Social Icon Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#233a95',
				'settings' => 'Bagola_footer_social_icon_color',
				'label' => esc_attr__( 'Footer Social Icon Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		
		/*====== Footer General Background ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#fff',
				'settings' => 'Bagola_footer_general_background',
				'label' => esc_attr__( 'Footer General Background Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for background.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer General Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9bb4',
				'settings' => 'Bagola_footer_general_color',
				'label' => esc_attr__( 'Footer General Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a font color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer General Hover Color ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'color',
				'default' => '#9b9bb4',
				'settings' => 'Bagola_footer_general_hvrcolor',
				'label' => esc_attr__( 'Footer General Hover Color', 'Bagola-core' ),
				'description' => esc_attr__( 'You can set a color for  color.', 'Bagola-core' ),
				'section' => 'Bagola_footer_style_section',
			)
		);
		
		/*====== Footer Typography ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'Bagola_footer_size',
				'label'       => esc_attr__( 'Footer Typography', 'Bagola-core' ),
				'section'     => 'Bagola_footer_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
					
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-footer .footer-widgets .widget , .klbfooterwidget h4.widget-title',
					],
				],
			)
		);
		
		/*====== Footer Featured Typography ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'Bagola_footer_featured_size',
				'label'       => esc_attr__( 'Footer Featured Typography', 'Bagola-core' ),
				'section'     => 'Bagola_footer_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
					
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-footer .footer-iconboxes .iconbox .iconbox-icon , .site-footer .footer-iconboxes .iconbox .iconbox-detail span ',
					],
				],
			)
		);
		
		/*====== Footer Contact Typography ======*/
		Bagola_customizer_add_field (
			array(
				'type'        => 'typography',
				'settings' => 'Bagola_footer_contact_size',
				'label'       => esc_attr__( 'Footer Contact Typography', 'Bagola-core' ),
				'section'     => 'Bagola_footer_style_section',
				'default'     => [
					'font-family'    => '',
					'variant'        => '',
					'font-size'      => '',
					'line-height'    => '',
					'letter-spacing' => '',
					'text-transform' => '',
					
				],
				'priority'    => 10,
				'transport'   => 'auto',
				'output'      => [
					[
						'element' => '.site-footer .footer-contacts .site-phone .entry-title, .site-footer .footer-contacts .site-phone span , .site-footer .footer-contacts .site-mobile-app .app-content .entry-title , .site-footer .footer-contacts .site-mobile-app .app-content span',
					],
				],
			)
		);

		/*====== GDPR Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_gdpr_toggle',
				'label' => esc_attr__( 'Enable GDPR', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of GDPR.', 'Bagola-core' ),
				'section' => 'Bagola_gdpr_settings_section',
				'default' => '0',
			)
		);

		/*====== GDPR Image======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'Bagola_gdpr_image',
				'label' => esc_attr__( 'Image', 'Bagola-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'Bagola-core' ),
				'section' => 'Bagola_gdpr_settings_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'required' => array(
					array(
					  'setting'  => 'Bagola_gdpr_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== GDPR Text ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'Bagola_gdpr_text',
				'label' => esc_attr__( 'GDPR Text', 'Bagola-core' ),
				'section' => 'Bagola_gdpr_settings_section',
				'default' => 'In order to provide you a personalized shopping experience, our site uses cookies. <br><a href="#">cookie policy</a>.',
				'required' => array(
					array(
					  'setting'  => 'Bagola_gdpr_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== GDPR Expire Date ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_gdpr_expire_date',
				'label' => esc_attr__( 'GDPR Expire Date', 'Bagola-core' ),
				'section' => 'Bagola_gdpr_settings_section',
				'default' => '15',
				'required' => array(
					array(
					  'setting'  => 'Bagola_gdpr_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== GDPR Button Text ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_gdpr_button_text',
				'label' => esc_attr__( 'GDPR Button Text', 'Bagola-core' ),
				'section' => 'Bagola_gdpr_settings_section',
				'default' => 'Accept Cookies',
				'required' => array(
					array(
					  'setting'  => 'Bagola_gdpr_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Newsletter Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_newsletter_popup_toggle',
				'label' => esc_attr__( 'Enable Newsletter', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of Newsletter Popup.', 'Bagola-core' ),
				'section' => 'Bagola_newsletter_settings_section',
				'default' => '0',
			)
		);

		/*====== Newsletter Type ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'radio-buttonset',
				'settings' => 'Bagola_newsletter_type',
				'label' => esc_attr__( 'Newsletter Type', 'Bagola-core' ),
				'section' => 'Bagola_newsletter_settings_section',
				'default' => 'type1',
				'choices' => array(
					'type1' => esc_attr__( 'Type 1', 'Bagola-core' ),
					'type2' => esc_attr__( 'Type 2', 'Bagola-core' ),
					'type3' => esc_attr__( 'Type 3', 'Bagola-core' ),
				),
				'required' => array(
					array(
					  'setting'  => 'Bagola_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Newsletter Image ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'Bagola_newsletter_image',
				'label' => esc_attr__( 'Image', 'Bagola-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'Bagola-core' ),
				'section' => 'Bagola_newsletter_settings_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'input_attrs' => array( 'class' => 'my_custom_class' ),

				'active_callback' => [
					[
					  'setting'  => 'Bagola_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					],
					[
					  'setting'  => 'Bagola_newsletter_type',
					  'operator' => '!=',
					  'value'    => 'type1',
					]
				],

			)
		);
		
		
		/*====== Newsletter Title ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_newsletter_popup_title',
				'label' => esc_attr__( 'Newsletter Title', 'Bagola-core' ),
				'section' => 'Bagola_newsletter_settings_section',
				'default' => 'Subscribe To Newsletter',
				'required' => array(
					array(
					  'setting'  => 'Bagola_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Newsletter Subtitle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'Bagola_newsletter_popup_subtitle',
				'label' => esc_attr__( 'Newsletter Subtitle', 'Bagola-core' ),
				'section' => 'Bagola_newsletter_settings_section',
				'default' => 'Subscribe to the Bagola mailing list to receive updates on new arrivals, special offers and our promotions.',
				'required' => array(
					array(
					  'setting'  => 'Bagola_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subcribe Popup FORM ID======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_newsletter_popup_formid',
				'label' => esc_attr__( 'Newsletter Form Id.', 'Bagola-core' ),
				'description' => esc_attr__( 'You can find the form id in Dashboard > Mailchimp For Wp > Form.', 'Bagola-core' ),
				'section' => 'Bagola_newsletter_settings_section',
				'default' => '',
				'required' => array(
					array(
					  'setting'  => 'Bagola_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);
		
		/*====== Subcribe Popup Expire Date ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_newsletter_popup_expire_date',
				'label' => esc_attr__( 'Newsletter Expire Date', 'Bagola-core' ),
				'section' => 'Bagola_newsletter_settings_section',
				'default' => '15',
				'required' => array(
					array(
					  'setting'  => 'Bagola_newsletter_popup_toggle',
					  'operator' => '==',
					  'value'    => '1',
					),
				),
			)
		);

		/*====== Maintenance Toggle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'toggle',
				'settings' => 'Bagola_maintenance_toggle',
				'label' => esc_attr__( 'Enable Maintenance Mode', 'Bagola-core' ),
				'description' => esc_attr__( 'You can choose status of Maintenance.', 'Bagola-core' ),
				'section' => 'Bagola_maintenance_settings_section',
				'default' => '0',
			)
		);
		
		/*====== Maintenance Title ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_maintenance_title',
				'label' => esc_attr__( 'Title', 'Bagola-core' ),
				'section' => 'Bagola_maintenance_settings_section',
				'default' => 'Coming',
				'active_callback' => [
					[
					  'setting'  => 'Bagola_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],
			)
		);

		/*====== Maintenance Second Title ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_maintenance_second_title',
				'label' => esc_attr__( 'Second Title', 'Bagola-core' ),
				'section' => 'Bagola_maintenance_settings_section',
				'default' => 'Soon',
				'active_callback' => [
					[
					  'setting'  => 'Bagola_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],
			)
		);
		
		/*====== Maintenance Subtitle ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'textarea',
				'settings' => 'Bagola_maintenance_subtitle',
				'label' => esc_attr__( 'Subtitle', 'Bagola-core' ),
				'section' => 'Bagola_maintenance_settings_section',
				'default' => 'Get ready! Something really cool is coming!',
				'active_callback' => [
					[
					  'setting'  => 'Bagola_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],
			)
		);
		
		/*====== Maintenance Mailchimp FORM ID======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'text',
				'settings' => 'Bagola_maintenance_mailchimp_formid',
				'label' => esc_attr__( 'Mailchimp Form Id.', 'Bagola-core' ),
				'description' => esc_attr__( 'You can find the form id in Dashboard > Mailchimp For Wp > Form.', 'Bagola-core' ),
				'section' => 'Bagola_maintenance_settings_section',
				'default' => '',
				'active_callback' => [
					[
					  'setting'  => 'Bagola_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],
			)
		);
		
		/*====== Maintenance Image ======*/
		Bagola_customizer_add_field (
			array(
				'type' => 'image',
				'settings' => 'Bagola_maintenance_image',
				'label' => esc_attr__( 'Background Image', 'Bagola-core' ),
				'description' => esc_attr__( 'You can upload an image.', 'Bagola-core' ),
				'section' => 'Bagola_maintenance_settings_section',
				'choices' => array(
					'save_as' => 'id',
				),
				'input_attrs' => array( 'class' => 'my_custom_class' ),
				'active_callback' => [
					[
					  'setting'  => 'Bagola_maintenance_toggle',
					  'operator' => '==',
					  'value'    => '1',
					]
				],

			)
		);